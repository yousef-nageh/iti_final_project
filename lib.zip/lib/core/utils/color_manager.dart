import 'dart:ui';

abstract class ColorManager{

static Color backGround =const Color(0xff212832);
static Color secondaryColor =const Color(0xffFED36A);
static Color whiteColor =const Color(0xffFFFFFF);
static Color blackColor =const Color(0xff000000);
static Color halfWhite =const Color(0xff8CAAB9);

static Color whiteGrey =const Color(0xff455A64);
static Color buttonNColor =const Color(0xff263238);


}