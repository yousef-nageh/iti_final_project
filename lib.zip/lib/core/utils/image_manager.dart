abstract class ImageManager{

static const logoImage="assets/images/logo.svg";
static const homeImage="assets/images/home_image.svg";
static const testImage="assets/images/test.png";
static const circelImage="assets/images/circle.svg";
}
