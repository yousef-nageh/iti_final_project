import 'package:flutter/cupertino.dart';

const double kPadding=26;
const fonts="PilatExtended";

