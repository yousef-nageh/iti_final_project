part of 'app_cubit.dart';


abstract class AppStates {}

class AppInitial extends AppStates {}
class BottomNavigationBarState extends AppStates {}
