abstract class AppString{
static const day="Day";
static const task="Task";
static const homeMText1="Manage your  Task with";
static const homeMText2="DayTask";
static const homeButtonText="Let’s Start";
static const welcomeBack="Welcome Back!";

static const emailAddress="Email Address";

static const password="Password";
static const forgotPassword= "Forgot Password?";
static const login= "Log In";

static const emailHintText="Enter your Email";

static const passwordHintText="Enter your Password";
static const userHintText="Enter your Name";

static const driverText="Or continue with";
static const googleText="Google";
static const createYourAccount="Create your account";
static const fullName="Full Name";
static const haveRead="I have read & agreed to DayTask ";
static const privacyPolicy="Privacy Policy, Terms & Condition";
static const signUpText="Sign Up";

static const searchTasks="Search tasks";
static const completedTasks="Completed Tasks";
static const seeAll="See all";
static const ongoingProjects="Ongoing Projects";
static const messages="Messages ";
static const chat="Chat ";
static const groups="Groups ";
static const startChat="Start Chat ";
static const schedule="Schedule ";
static const todayTasks="Today’s Tasks ";
static const notifications="Notifications";
static const news="New";
static const earlier="Earlier";
static const taskDetails="Task Details";
static const realEstateAppDesign="Real Estate App Design";
static const projectDetails="Project Details";
static const projectProgress="Project Progress";
static const allTasks="All Tasks";














}