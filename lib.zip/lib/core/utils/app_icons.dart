abstract class AppIcons{

  static const emailIcon="assets/icons/email.svg";
  static const passwordIcon="assets/icons/Password.svg";
  static const passwordEyeIcon="assets/icons/password_eye.svg";
  static const userIcon="assets/icons/user.svg";
  static const googleIcon="assets/icons/google.svg";
  static const trueIcon="assets/icons/true_icon.svg";
  static const homeIcon="assets/icons/home.svg";

 static const calendarIcon="assets/icons/calendar.svg";
  static const chatIcon="assets/icons/chat.svg";

static const notificationIcon="assets/icons/notification.svg";
static const searchIcon="assets/icons/search.svg";
static const settingIcon="assets/icons/setting.svg";
static const editIcon="assets/icons/edit.svg";
static const arrowIcon="assets/icons/arrow_back.svg";
static const addSquare="assets/icons/add_square.svg";

static const trueIconTask="assets/icons/true_circle.svg";




}